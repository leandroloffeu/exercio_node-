// server.js
const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./config/db');
const userRoutes = require('./routes/userRoutes');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// Conectar ao MongoDB
connectDB();

// Usar as rotas
app.use('/api', userRoutes);

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
